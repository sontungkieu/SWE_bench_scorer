#!/usr/bin/env bash
set -e
set -a
. "$HOME/.config/swebench-web/service.env"
set +a
export MODAL_PROFILE=phamvanvuhoan
export MPL_DIAG_COMMIT=ade0cea
base="$HOME/apps/swebench-snapshot-probe"
src="$base/mpl-timing-src-ade0cea"
run="$base/mpl-timing-20261022-01"
cd "$src"
set +e
"$HOME/apps/swebench-web/runtime/venv/bin/python" -u probes/matplotlib_timing_probe.py run --out "$run" --source "$src" --reference "$base/n11max-cap2-24-20261022-01"
code=$?
printf '%s\n' "$code" > "$run/exit-code.txt"
exit "$code"
