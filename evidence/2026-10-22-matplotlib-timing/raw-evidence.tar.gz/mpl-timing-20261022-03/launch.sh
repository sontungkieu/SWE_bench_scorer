#!/usr/bin/env bash
set -e
set -a
. "$HOME/.config/swebench-web/service.env"
set +a
export MODAL_PROFILE=phamvanvuhoan
export MPL_DIAG_COMMIT=3d0cb53
base="$HOME/apps/swebench-snapshot-probe"
src="$base/mpl-timing-src-3d0cb53"
run="$base/mpl-timing-20261022-03"
py="$HOME/apps/swebench-web/runtime/venv/bin/python"
export MPL_PRIOR_COMPLETED_DIAG_BOUND_USD="$("$py" - "$base/mpl-timing-20261022-02/receipt.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]));assert r['all_vms_terminated']
print(r['wall_seconds']*(16*.00003942+64*.00000667))
PY
)"
cd "$src"
set +e
"$py" -u probes/matplotlib_timing_probe.py run --out "$run" --source "$src" --reference "$base/n11max-cap2-24-20261022-01"
code=$?
printf '%s\n' "$code" > "$run/exit-code.txt"
exit "$code"
