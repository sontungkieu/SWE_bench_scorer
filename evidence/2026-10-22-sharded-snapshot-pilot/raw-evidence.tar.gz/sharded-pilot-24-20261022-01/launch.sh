#!/usr/bin/env bash
set -u
set -a
. "$HOME/.config/swebench-web/service.env"
set +a
code="$HOME/apps/swebench-snapshot-probe/sharded-pilot-src-b6191e2"
out="$HOME/apps/swebench-snapshot-probe/sharded-pilot-24-20261022-01"
cd "$code"
"$HOME/apps/swebench-web/runtime/venv/bin/python" -u probes/sharded_pilot.py run --out "$out" --source "$HOME/apps/swebench-web/releases/6650928" --baseline "$HOME/apps/swebench-upstream-probe/cost-pilot-20261022-01"
result=$?
printf '%s\n' "$result" > "$out/exit-code.txt"
exit "$result"
