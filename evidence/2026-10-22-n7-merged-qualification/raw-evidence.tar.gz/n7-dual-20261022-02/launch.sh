#!/bin/bash
set -u
root=/home/kieusontung8/apps/swebench-snapshot-probe
out="$root/n7-dual-20261022-02"
source="$root/n7-src-ea97319"
set -a
. /home/kieusontung8/.config/swebench-web/service.env
set +a
cd "$source"
/home/kieusontung8/apps/swebench-web/runtime/venv/bin/python -u probes/merged_snapshot_experiment.py run --out "$out" --source "$source"
code=$?
printf '%s\n' "$code" > "$out/exit-code.txt"
exit "$code"
