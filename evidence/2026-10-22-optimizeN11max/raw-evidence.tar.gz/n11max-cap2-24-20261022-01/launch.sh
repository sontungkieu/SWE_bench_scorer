#!/usr/bin/env bash
set -e
set -a
. "$HOME/.config/swebench-web/service.env"
set +a
export MODAL_PROFILE=phamvanvuhoan
base="$HOME/apps/swebench-snapshot-probe"
src="$base/n11max-src-c26058d"
run="$base/n11max-cap2-24-20261022-01"
py="$HOME/apps/swebench-web/runtime/venv/bin/python"
cd "$src"
set +e
"$py" -u eval_modes.py run --mode optimizeN11max --out "$run" --source "$src" --baseline "$HOME/apps/swebench-upstream-probe/cost-pilot-20261022-01"
code=$?
printf '%s\n' "$code" > "$run/exit-code.txt"
exit "$code"
